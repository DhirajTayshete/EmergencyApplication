package com.acts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acts.emergency.EmergencyAssistance;
import com.acts.emergency.EmergencyAssistance.Contact;
import com.acts.services.EmergencyAssistanceServices;

@RestController
@RequestMapping("/api/emergency")
public class EmergencyController {
    
//    private final EmergencyAssistance emergencyAssistance;
    
    @Autowired
    private EmergencyAssistanceServices emergencyAssistanceServices;
    
//    public EmergencyController(EmergencyAssistance emergencyAssistance) {
//        this.emergencyAssistance = emergencyAssistance;
//    }

    @PostMapping("/call/{serviceType}")
    public ResponseEntity<String> callEmergencyServices(@PathVariable String serviceType) {
        // Logic to call emergency services
    	emergencyAssistanceServices.callEmergencyServices(serviceType);
        return ResponseEntity.ok("Emergency services called successfully");
    }

    @PostMapping("/medical-history")
    public ResponseEntity<String> storeMedicalHistory(@RequestBody String medicalHistory) {
        // Logic to store medical history
    	emergencyAssistanceServices.storeMedicalHistory(medicalHistory);
        return ResponseEntity.ok("Medical history stored successfully");
    }

    @GetMapping("/emergency-contacts")
    public ResponseEntity<List<EmergencyAssistance.Contact>> getEmergencyContacts() {
        // Logic to retrieve emergency contacts
        List<EmergencyAssistance.Contact> emergencyContacts = emergencyAssistanceServices.getEmergencyContacts();
        return ResponseEntity.ok(emergencyContacts);
    }
    
    
}

