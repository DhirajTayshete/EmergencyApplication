package com.acts.services;

import java.util.List;

import com.acts.emergency.EmergencyAssistance;
import com.acts.emergency.EmergencyAssistance.Contact;


public interface EmergencyAssistanceServices {

	   void callEmergencyServices(String serviceType);
	    
	   void storeMedicalHistory(String medicalHistory);
	    
	   List<Contact> getEmergencyContacts();
}
