package com.acts.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.acts.emergency.EmergencyAssistance;
import com.acts.emergency.EmergencyAssistance.Contact;
import com.acts.repositories.EmergencyAssistanceRepo;


public class EmergencyAssistanceImpl implements EmergencyAssistanceServices{

	@Autowired
	private EmergencyAssistanceRepo emergencyAssistanceRepo;
	
	@Autowired
	private EmergencyAssistance emergencyAssistance;
	
	@Override
	public void callEmergencyServices(String serviceType) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void storeMedicalHistory(String medicalHistory) {
		this.emergencyAssistance.getMedicalHistoryList().add(medicalHistory);
//		List<String> mh=this.emergencyAssistance.getMedicalHistoryList();
//		mh.add(medicalHistory);
//		this.emergencyAssistance.setMedicalHistoryList(null);
	}

	@Override
	public List<Contact> getEmergencyContacts() {
		// TODO Auto-generated method stub
		return null;
	}
}
