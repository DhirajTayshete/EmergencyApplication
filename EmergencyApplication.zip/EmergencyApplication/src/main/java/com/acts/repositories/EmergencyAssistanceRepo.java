package com.acts.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.acts.emergency.EmergencyAssistance;

public interface EmergencyAssistanceRepo extends JpaRepository<EmergencyAssistance,Long>{

}
